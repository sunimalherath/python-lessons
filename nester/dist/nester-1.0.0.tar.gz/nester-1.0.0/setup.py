from distutils.core import setup

setup(
    name="nester",
    version="1.0.0",
    py_modules=["nester"],
    author="Sunimal Herath - hfpython",
    author_email="sunimal**@gmail.com",
    url="",
    description="A simple printer of nested lists",
)
